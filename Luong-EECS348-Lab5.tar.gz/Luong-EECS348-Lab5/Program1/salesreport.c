/* 
    Author: Jenna Luong
    Date: 10/11/2023
    Purpose: create a program that imitates a sales report
*/
#include <stdio.h>

int main() {
    //pointer variable array for the 12 months
    char *months[] = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
    
    //an array for sales w size of 12 for each month
    float sales[12];

    //opens and read sales.txt
    FILE *file = fopen("sales", "r");

    if (file == NULL) {
        printf("File Error");
        return 1; // returns an error code
    }

    // stores the data (floats) from file into memory address of sales using &
    for (int i = 0; i < 12; i++) {
        fscanf(file, "%f", &sales[i]);
    }

    fclose(file); // closes file

    //monthly sales report
    printf("Monthly sales report for 2022:\n");
    printf("\nMonth\t        Sales\n");
    //prints the months with the corresposnding sales. 0-11
    for (int i = 0; i < 12; i++) 
    {
        //%-8s bc the months are strings & i want to add trailing spaces to align the sales, %.2f bc we want the number to end at the hundredths place
        printf("%-8s\t$%.2f\n", months[i], sales[i]);
    }

    // sales summary
    float min_sale = sales[0]; // assumes sales[0] is the min so we can compare
    float max_sale = sales[0]; // assumes sales[0] is the max so we can compare
    float total = 0; // total = 0 so we can add up all sales
    float avg; // initialize average
    int min_index = 0; // index for min
    int max_index = 0; // index for max

    //finds total, min, and max sale
    for (int i = 0; i < 12; i++) {
        total += sales[i]; // adds up all sales
        // checks if the current index of sales is less than the min sale. if it is then reassign min_sale to current index
        if (sales[i] < min_sale) {
            min_sale = sales[i];
            min_index = i; // index of min to print month
        }
        // checks if the current index of sales is more than the max sale. if it is then reassign max_sale to current index
        if (sales[i] > max_sale) {
            max_sale = sales[i];
            max_index = i; // index of max to print month
        }
    }
    avg = total/12; // average is the total/12 for the 12 months

    // prints sales summary
    printf("\n\nSales Summary:\n");
    printf("Minimum sales:\t$%.2f  (%s)\n", min_sale, months[min_index]);
    printf("Maximum sales:\t$%.2f  (%s)\n", max_sale, months[max_index]);
    printf("Average sales:\t$%.2f\n", avg);

    //six-month average report
    // indices: 0-5, 1-6, 2-7, 3-8, 4-9, 5-10, 6-11
    printf("\n\nSix-Month Moving Average Report:\n");

    // jan-june
    total = 0;
    for (int i = 0; i < 6; i++) {
        total += sales[i]; // adds sales from jan-june
    }
    avg = total / 6; // avg of those 6 months
    printf("%-8s\t-  %-5s\t$%.2f\n", months[0], months[5], avg);

    //feb-july
    total = 0;
    for (int i = 1; i < 7; i++) {
        total += sales[i]; // same as described above but w diff months
    }
    avg = total / 6;
    printf("%-8s\t-  %-5s\t$%.2f\n", months[1], months[6], avg);

    //march-aug
    total = 0;
    for (int i = 2; i < 8; i++) {
        total += sales[i]; // same as described above but w diff months
    }
    avg = total / 6;
    printf("%-8s\t-  %-5s\t$%.2f\n", months[2], months[7], avg);

    //apr-sep
    total = 0;
    for (int i = 3; i < 9; i++) {
        total += sales[i]; // same as described above but w diff months
    }
    avg = total / 6;
    printf("%-8s\t-  %-5s\t$%.2f\n", months[3], months[8], avg);

    //may-oct
    total = 0;
    for (int i = 4; i < 10; i++) {
        total += sales[i]; // same as described above but w diff months
    }
    avg = total / 6;
    printf("%-8s\t-  %-5s\t$%.2f\n", months[4], months[9], avg);

    //june-nov
    total = 0;
    for (int i = 5; i < 11; i++) {
        total += sales[i]; // same as described above but w diff months
    }
    avg = total / 6;
    printf("%-8s\t-  %-5s\t$%.2f\n", months[5], months[10], avg);

    //july-dec
    total = 0;
    for (int i = 6; i < 12; i++) {
        total += sales[i]; // same as described above but w diff months
    }
    avg = total / 6;
    printf("%-8s\t-  %-3s\t$%.2f\n", months[6], months[11], avg);
    
    // sales report (highest to lowest)
    printf("\n\nSales Report (Highest to Lowest):\n");
    printf("Month\t        Sales\n");
    for (int i = 0; i < 12; i++) {
        // i + 1 bc we want to compare to the months after i
        for (int j = i + 1; j < 12; j++) {
            // swap sales & months
            if (sales[i] < sales[j]) {
                // we are storing sales[i] in a temp value so that we don't lose sales[i] when swapping the two 
                float temp_sale = sales[i];
                sales[i] = sales[j]; // sales[i] is now sales[j]
                sales[j] = temp_sale; // sales[j] is now sales[i]

                // same concept as the above
                char *temp_month = months[i];
                months[i] = months[j];
                months[j] = temp_month;
            }
        }
    }
    // printing each month & sale after swapping needed months
    for (int i = 0; i < 12; i++) {
        printf("%-8s\t$%.2f\n", months[i], sales[i]);
    }
    return 0;
}