/* 
    Author: Jenna Luong
    Date: 10/14/2023
    Purpose: create a program that determines the football score possibilities
*/

#include <stdio.h>

int main() {
    int score;
    // calculates safeties first then fg all the way to td2pt. prints the possibilities if it equals score then loops until all possibilities exhausted then prompts 
    // user to pick another score until the user score is 1 or less than 1.
    while (1) {
        printf("Enter 0 or 1 to STOP\nEnter the NFL score: ", score);
        scanf("%d", &score);
        if (score <= 1) {
            break;
        }
        printf("Possible combinations of scoring plays:\n");
        // td + 2pt conversion
        for (int td2pt = 0; td2pt <= score/8; td2pt++) {
            // td + fg
            for (int tdfg = 0; tdfg <= score/7; tdfg++) {
                //td
                for (int td = 0; td <= score/6; td++) {
                    // fg
                    for (int fg = 0; fg <= score/3; fg++) {
                        // safety
                        for (int safety = 0; safety <= score/2; safety++) {
                            // we want to multiply the points to the variables to get full score bc the above only calculates the amount
                            if (8*td2pt + 7*tdfg + 6*td + 3*fg + 2*safety == score) {
                                printf("%d TD + 2pt, %d TD + FG, %d TD, %d 3pt FG, %d Safety\n", td2pt, tdfg, td, fg, safety);
                            }
                        }
                    }
                }
            }
        }
    }
    return 0;
}